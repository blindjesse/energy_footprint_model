/* pause()  - Pauses processing - used for diagnostics.
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <malloc.h>
#include <math.h>
 
 

 

void	pause()
{

	char	ans[255];

	gets(ans);

}