/* Global file names for roads and pads.
*/
char		theroads[255]; /* roads grid */
char		theroadsid[255];  /* rdidgeo.b file name */
char		thepads[255];  /* pads grid */
