/* Global pointers to track pad allocation by AU x PROJ.
*/
FILE			*sumrates;	 /* file containing summary of pad allocation by au x proj */
FILE			*sumratesp;  /*  "  " by project */